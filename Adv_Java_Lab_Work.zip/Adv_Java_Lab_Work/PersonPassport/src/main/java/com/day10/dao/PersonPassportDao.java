package com.day10.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.day10.personpassword.Passport;
import com.day10.personpassword.Person;

public class PersonPassportDao {

	public void add(Person person) {
		
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		tx.begin();
		em.persist(person);

	tx.commit();
	emf.close();
	
	}
//***************************************************************************************************
	public Person fetchbypassportNo(int passportNo) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		
		javax.persistence.Query q = em.createQuery("select p from Person p join p.passport ps where ps.passportNo = :pno");
		((javax.persistence.Query) q).setParameter("pno", passportNo);
		Person p = (Person) ((javax.persistence.Query) q).getSingleResult();
		emf.close();

		return p;
	}
	                                              //leo leo@outlook.com
	//***************************************************************************************************
	

	public List<Person> fetchPersonsByPassportExpiryYear(int year) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();

		javax.persistence.Query q = em.createQuery("select p from Person p join p.passport ps where year(ps.expiryDate) = :yr");
		//Query q = em.createQuery("select p from Passport ps join ps.person p where year(ps.expiryDate) = :yr");
		q.setParameter("yr", year);
		List<Person> list = q.getResultList();
		emf.close();

		return list;
	}
	
//	Select ab,p.name from Person p join p.passport ab where year(dateofBirth)= :dob"
	
	//***************************************************************************************************
	
	public List<Passport> fetchissueby(String issue) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();

		javax.persistence.Query q = em.createQuery("select ps from Passport ps where issuedBy = :iss");
		q.setParameter("iss", issue);
		List<Passport> list = q.getResultList();
		emf.close();

		return list;
	}
	
	//********************************************************************************************************
	
	public List<Passport> fetchyearDOB(int year) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();

		javax.persistence.Query q = em.createQuery("Select ab from Person p join p.passport ab where year(dateofBirth)= :dob");
		q.setParameter("dob", year);
		List<Passport> list = q.getResultList();
		emf.close();

		return list;
	}
	
	
	//********************************************************************************************************
	
	public List<Person> fetchdetailsOfPerson(String name) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();

		javax.persistence.Query q = em.createQuery("Select p from Person p where name= :nm");
		q.setParameter("nm", name);
		List<Person> list = q.getResultList();
		emf.close();

		return list;
	}
	
	
	//*************************************************************************************************************	
	
	
	public List<Passport> fetchdetailsOnDomain(String domain) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();

		javax.persistence.Query q = em.createQuery("Select ps from Passport ps join ps.person p where email like :eml");
		q.setParameter("eml", "%"+domain+"%");
		List<Passport> list = q.getResultList();
		emf.close();

		return list;
	}
	
	
	//*****************************************************************************************
	
	
	public List<Passport> fetchAll() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();

		javax.persistence.Query q = em.createQuery("select ps from Passport ps"); //HQL/JPQL
		List<Passport> list = q.getResultList();
		
		return list;
	}
	
	
	
	
	
	
	
	
	
	
	
}
