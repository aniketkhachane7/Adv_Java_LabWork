package com.day10.main;

import java.security.PublicKey;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.day10.dao.PersonPassportDao;
import com.day10.personpassword.Passport;
import com.day10.personpassword.Person;
import com.mysql.cj.Query;

public class PersonPassportExample {

	public static void main(String[] args) {
		
		PersonPassportDao  dao = new PersonPassportDao();
	/*	
		Person person = new Person();
		person.setId(50);
		person.setName("robert");
		person.setEmail("robert@gamil.com");
		person.setDateOfBirth(LocalDate.of(2015,6, 16));
		
		Passport passport = new Passport();
	
		passport.setPassportNo(500);
		passport.setIssueDate(LocalDate.of(2021, 3, 15));
		passport.setExpiryDate(LocalDate.of(2031, 3, 15));
		passport.setIssuedBy("gov. of india");
		
		
		person.setPassport(passport);
		passport.setPerson(person);
		
		dao.add(person);  */
		
		
		Person p = dao.fetchbypassportNo(300);
		System.out.println(p.getName() + " " + p.getEmail());
		
		System.out.println(" *********************************** ");

//		List<Person> list = dao.fetchPersonsByPassportExpiryYear(2030);
//		for(Person p1 : list)
//			System.out.println(p1.getName() + " " + p1.getEmail());
	
		System.out.println(" *********************************** ");
		
//		List<Passport> list1 = dao.fetchissueby("Govt. of India");
//		for(Passport p2 : list1)
//			System.out.println(p2.getPassportNo() + " " + p2.getExpiryDate()+ " " + p2.getIssueDate());
	
		System.out.println(" *********************************** ");

//		List<Passport> list11 = dao.fetchyearDOB(1999);
//		for(Passport p2 : list11)
//			System.out.println(p2.getPerson().getName()+ " -- " +p2.getPassportNo() + " -- " + p2.getExpiryDate()+ " -- " + p2.getIssueDate());
		
		System.out.println(" *********************************** ");
		
//		List<Person> list2 = dao.fetchdetailsOfPerson("robert");
//		for(Person p3 : list2)
//			System.out.println(p3.getId() + "__" + p3.getDateOfBirth()+ "__" + p3.getEmail());
		
		
System.out.println(" *********************************** ");
		
		List<Passport> list3 = dao.fetchdetailsOnDomain("gmail");
		for(Passport p4 : list3)
			System.out.println(p4.getPerson().getName()+"__"+p4.getPassportNo() + " " + p4.getExpiryDate()+ " " + p4.getIssueDate()+ " " + p4.getIssuedBy());
		
		
		
		System.out.println(" *********************************** ");
		
		List<Passport> list4 =  dao.fetchAll();
		for(Passport p5 : list4)
			System.out.println(p5.getPerson().getName()+"__"+p5.getPassportNo() + " " + p5.getExpiryDate()+ " " + p5.getIssueDate()+ " " + p5.getIssuedBy());
		
		
	/*	Swapnil__1 2030-10-30 2020-10-30 Govt. of India
		Harry__100 2030-10-01 2020-10-01 gov. of india
		jack__200 2031-01-14 2021-01-14 gov. of india
		leo__300 2031-02-14 2021-02-14 gov. of india
		Aniket__400 2031-03-15 2021-03-15 gov. of india
		robert__500 2031-03-15 2021-03-15 gov. of india */
		
		
		
		
	}

}
