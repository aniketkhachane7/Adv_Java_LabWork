package com.pack;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalTime;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//@WebServlet("/Booking.com")
public class TatkalBookingServlet1 extends HttpServlet {
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
			PrintWriter out = response.getWriter();
		ServletConfig cfg =getServletConfig();
		
		int startTime = Integer.parseInt(cfg.getInitParameter("startTime"));
		int endTime = Integer.parseInt(cfg.getInitParameter("endTime"));
		
		LocalTime time = LocalTime.now();
		int timeRightnow = time.getHour();
		
		if(timeRightnow >= startTime && timeRightnow <= endTime) {
			
			out.println("<h1> Booking site is on......... </h1>");
		}
		else {
			
			out.println("<h1> oops yrrr Booking time over.... </h1>");
		}
		
		
		
	}

}
