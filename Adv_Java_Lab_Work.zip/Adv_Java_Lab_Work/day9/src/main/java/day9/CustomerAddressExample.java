package day9;

import java.util.List;

public class CustomerAddressExample {

	public static void main(String[] args) {
	
		CustomerAddressDao dao = new CustomerAddressDao();

//		Customer c = new Customer();
//		c.setId(20);
//		c.setName("robert");
//		c.setEmail("robert@gmail.com");
//		dao.add(c);
//		
//		Address a = new Address();
//		a.setId(200);
//		a.setPincode(202020);
//		a.setCity("mumbai");
//		a.setState("MH");
//		
//		dao.add(a);
//	
//
//		Customer c1 = dao.fetchCustomer(20);
//		Address a1 = dao.fetchAddress(200);
//		
//		c1.setAddress(a1);
//		dao.update(c1);          // method call
		
	/*	
		Customer c = new Customer();
		c.setId(60);
		c.setName("Mohini");
		c.setEmail("Mohini@gmail.com");
		
		
		Address a = new Address();
		a.setId(600);
		a.setPincode(606060);
		a.setCity("viman nagar");
		a.setState("MH");
		
		
		c.setAddress(a); // we have create obj of address class in customer to establish relationship(fk) 
		dao.add(c);        //so we have save detail of address in customer table
	*/
		
		
		
	/*	List<Customer> list = dao.fetchCustomersByEmail("gmail");
		for(Customer c : list)
			System.out.println(c.getId() + " " + c.getName() + " " + c.getEmail());
	*/	
	
//		 List<Address> list = dao.fetchAddressDetails("MP");
//			for(Address a : list)
//				System.out.println(a. getId() + " " + a.getCity() + " " + a.getPincode());
//		
		 
	/*	 List<Customer> list = dao.fetchCustomersByCity("jalgaon");
		for(Customer c : list)
			System.out.println(c.getId() + " " + c.getName() + " " + c.getEmail());
		
	*/	
		
		
	/*	Address a = dao.fetchAddressByCustomerName("Mohini");
		System.out.println(a.getId() + " " + a.getCity() + " " + a.getPincode() + " " + a.getState());
	*/	
	

		List<Address> list = dao.fetchCustomeroncity("pune");
		for(Address a : list)
			System.out.println(a.getId() + " " + a.getPincode() + " " + a.getState());
	
	
	
	}
}
