package com.cdac.main;



import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.component.Atm;

public class App {

	public static void main(String[] args)  {
	

	
		
  	ApplicationContext ctx = new ClassPathXmlApplicationContext("my-spring-config.xml");

		
		Atm atm = (Atm) ctx.getBean("abcd");
		atm.withdraw(20202020, 5000);
	}

}
