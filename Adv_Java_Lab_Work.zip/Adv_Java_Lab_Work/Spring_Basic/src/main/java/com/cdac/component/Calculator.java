package com.cdac.component;

public class Calculator {
	
	
	public void add(int x, int y) {
		
		System.out.println("Addition : "+ (int)(x+y));
		
		//return x+y;
	}
	
	public void sub(int x, int y) {
		
		System.out.println("Substraction : "+ (x-y));
		
		//return x-y;
	}
	
	
}
