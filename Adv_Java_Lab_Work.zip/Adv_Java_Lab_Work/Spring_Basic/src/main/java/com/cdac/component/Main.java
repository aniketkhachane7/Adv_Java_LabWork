package com.cdac.component;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		ApplicationContext ctx = new ClassPathXmlApplicationContext("my-spring-config.xml");
		HelloWorld hello = (HelloWorld) ctx.getBean("hello"); //By using .xml file
		
		System.out.println(hello.sayhello("Aniket "));
		
		
		Calculator  cal = ctx.getBean("calc",Calculator.class); //By using .xml file
		
					//	System.out.println(cal.add(10, 40));
					//	System.out.println(cal.sub(50, 25));
			
		cal.add(10, 40);
		cal.sub(10, 40);
	
//****************************//By using @Annotation ****************************
	
		CurrencyConverter cc = (CurrencyConverter) ctx.getBean("CurrencyConv");
		
		System.out.println("Currency converted USD TO INR : "+cc.convert("USD","INR",650));
		System.out.println("Currency converted GPB TO INR : "+cc.convert("GPB","INR",500));
															
//********************************************************************	
		
		SizeConvertor sc = (SizeConvertor) ctx.getBean("SizeConv");
		
		System.out.println("Size converted meter to cm : "+sc.convert("meter","cm",1));
		System.out.println("Size converted foot to cm : "+sc.convert("foot","cm",5));
//************************************************************************
		
		TextEditor te = (TextEditor) ctx.getBean("txtEditor");
	te.load("abc.txt");
		
		
//**************************************************************************
	Car car = (Car) ctx.getBean("car");
	car.drive();		
		
		
		
		
		}	
		
	}
