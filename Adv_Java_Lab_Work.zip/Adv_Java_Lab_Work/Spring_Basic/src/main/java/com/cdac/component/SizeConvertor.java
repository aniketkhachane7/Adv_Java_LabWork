package com.cdac.component;

import org.springframework.stereotype.Component;

@Component("SizeConv")
public class SizeConvertor {
	public double convert(String from, String to, double x) {
		if(from.equals("meter") && to.equals("cm"))
			return 100 * x;
		else if(from.equals("foot") && to.equals("cm"))
			return 30.48 * x;
		else
			return 0;
	}
	
	
}
