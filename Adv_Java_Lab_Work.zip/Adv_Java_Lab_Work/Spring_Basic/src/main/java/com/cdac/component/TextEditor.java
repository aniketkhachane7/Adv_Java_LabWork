package com.cdac.component;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("txtEditor")
public class TextEditor {

	@Autowired
	private SpellChecker sc;
	
	void load(String document) {
		System.out.println("code for loading : "+document);
		// TODO Auto-generated method stub

		sc.CheckSpellingMistake(document);
	}
}
