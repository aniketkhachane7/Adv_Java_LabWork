package com.cdac.component;

import org.springframework.stereotype.Component;

@Component("SplCheck")
public class SpellChecker {

	public void CheckSpellingMistake(String document) {
		
		
	}
}
