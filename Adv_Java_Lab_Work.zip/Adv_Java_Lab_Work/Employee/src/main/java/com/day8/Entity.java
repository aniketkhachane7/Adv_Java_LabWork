package com.day8;

public @interface Entity {

}
