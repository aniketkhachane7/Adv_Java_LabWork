package com.cdac.component;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class MainClass {

	public static void main(String[] args) {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("my-spring-config.xml");
		

		HdfcATM hdfc = (HdfcATM) ctx.getBean("abcd");
		hdfc.withdraw(101010, 5000);
		
		Atm atm = (Atm)ctx.getBean("abcd");
		atm.withdraw(202020, 5000);	
		
	}

}
