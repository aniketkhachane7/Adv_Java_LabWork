package com.cdac.component;

import org.springframework.stereotype.Component;

@Component
public interface Bank {
	public void withdraw(int atmId, int acno, double amount);
}
