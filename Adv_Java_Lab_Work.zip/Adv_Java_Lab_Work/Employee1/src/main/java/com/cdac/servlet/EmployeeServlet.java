package com.cdac.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cdac.Employee_HTML;
import com.cdac.dao.EmployeeDao;

public class EmployeeServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		Employee_HTML empo =new Employee_HTML();
		empo.setEmpno(Integer.parseInt(request.getParameter("Empno")));
		empo.setName(request.getParameter("Empname"));
		empo.setSalary(Double.parseDouble(request.getParameter("salary")));
		empo.setDateOfJoin(LocalDate.parse(request.getParameter("date_of_join")));
		
		EmployeeDao dao =new EmployeeDao();
		dao.add(empo);	
		
		
		PrintWriter out = response.getWriter();
		
		out.write("<html><body>");
		
		out.write("<h1> Added  <h1>");
		
		out.write("</body></html>");
		
		
		
		
	}

}
