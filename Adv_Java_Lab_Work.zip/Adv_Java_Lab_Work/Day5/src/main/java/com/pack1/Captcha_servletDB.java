package com.pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Captcha_servlet
 */
@WebServlet("/captcha.com")
public class Captcha_servletDB extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		int rollno = Integer.parseInt(request.getParameter("rollno"));
		String name = request.getParameter("name");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/advance_java","root","cdac");
	        PreparedStatement st= conn.prepareStatement("insert into zerobugs(rollno, name,username,password ) values(?,?,?,?)");
			
	        st.setInt(1, rollno);
	        st.setString(2, name);
			st.setString(3, username);
			st.setString(4, password);
			st.executeUpdate();
			conn.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		PrintWriter out1 = response.getWriter();
		out1.write("<html><body>");
		out1.write("<h1> Registration successful! </h1>");
		out1.write("</body></html>");
		
	}

}
