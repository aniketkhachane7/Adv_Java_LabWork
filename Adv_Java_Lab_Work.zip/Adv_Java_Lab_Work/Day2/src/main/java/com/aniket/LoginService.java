package com.aniket;

public class LoginService {

	public boolean verifydetails(String username, String password) {

		if (username.equals("aniket") && password.equals("1234"))
			return true;
		return false;

	}

}
