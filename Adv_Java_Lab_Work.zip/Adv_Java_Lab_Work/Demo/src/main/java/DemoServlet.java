

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class DemoServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/advance_java", "aniket1", "cdac");
			PreparedStatement st = conn.prepareStatement(
					"insert into student1(id,name) values(?, ?)");
			st.setInt(1, id);
			st.setString(2, name); // substituting ? with actual value
			st.executeUpdate();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		PrintWriter out = response.getWriter();
		out.write("<html><body>");
		out.write("<h1> Details added Successfully! </h1>");
		out.write("</body></html>");
	}

}
