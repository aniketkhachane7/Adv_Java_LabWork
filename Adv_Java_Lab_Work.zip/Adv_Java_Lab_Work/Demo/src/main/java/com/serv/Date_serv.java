package com.serv;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Date_serv")
public class Date_serv extends HttpServlet {
	
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			LocalDate today = LocalDate.now(); // Today's date is 10th Jan 2022
			LocalDate birthday = LocalDate.of(2015, Month.NOVEMBER, 20); // Birth date

			Period p = Period.between(birthday, today);
			out.write("<html><body>");
			out.write("<h1>Hello Again!</h1>");
			out.write("<h2>My Age Is : " +"year : "+p.getYears()+ " Month : "+p.getMonths()+" Day : "+p.getDays()+"</h2>");
			out.write("</body></html>");
		
		
		
		
	}

}
