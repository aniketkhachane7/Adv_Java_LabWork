package pack.day8;


import java.time.LocalDate;
import java.util.List;

import com.cdac.entity.Employee;


public class InsertEmployee {

	public static void main(String[] args) {
		/*Employee emp = new Employee();
		emp.setEmpno(1009);
		emp.setName("ketan");
		emp.setSalary(70000);
		emp.setDateofjoining(LocalDate.of(2018, 7, 18));

		EmployeeDao dao = new EmployeeDao();
		dao.add(emp);*/
		
		/*EmployeeDao dao = new EmployeeDao();
		Employee emp = dao.fetch(1009);
		System.out.println(emp.getName() + " " + emp.getSalary());
		*/
		
		/*EmployeeDao dao = new EmployeeDao();
		List<Employee> list = dao.fetchAll();
		for(Employee emp : list)
			System.out.println(emp.getEmpno() + "--" + emp.getName() + "--" + emp.getSalary() + "--" + emp.getDateofjoining());
        */
		
		
		/*EmployeeDao dao = new EmployeeDao();
		System.out.println(".............");
		List<Employee> list2 = dao.fetchAllBySalary(7000);
		for(Employee emp : list2)
		System.out.println(emp.getEmpno() + " " + emp.getName() + " " + emp.getSalary() + " " + emp.getDateofjoining());
		*/
		
		
		System.out.println("..............");
		EmployeeDao dao = new EmployeeDao();
		List<String> names = dao.fetchAllNames();
		for(String name : names)
			System.out.println(name);
		
		
		
}
	/*public static void main(String[] args) {
		//During this step, the persistence.xml file will be read
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		Employee emp = new Employee();
		emp.setEmpno(1002);
		emp.setName("Vipul");
		emp.setSalary(10000);
		emp.setDateOfJoining(LocalDate.of(2019, 10, 10));
		em.persist(emp); //persist method will generate insert query
		
		tx.commit();
		
		emf.close();
	}*/
	
}
