package com.cdac.entity;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class InsertEmployee {
	public static void main(String[] args) {
		//During this step, the persistence.xml file will be read
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		Employee emp = new Employee();
		emp.setEmpno(100);
		emp.setName("z");
		emp.setSalary(1000);
		emp.setDateofjoining(LocalDate.of(2021, 11, 11));
		em.persist(emp); //persist method will generate insert query
		
		tx.commit();
		
		emf.close();
	}
}
