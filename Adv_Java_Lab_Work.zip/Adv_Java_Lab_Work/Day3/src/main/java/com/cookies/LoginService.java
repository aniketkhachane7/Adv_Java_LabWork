package com.cookies;

public class LoginService {

	public boolean loginCheck(String username, String password) {
		if(username.equals("aniket") && password.equals("1234"))
			return true;
		return false;
	}

}
