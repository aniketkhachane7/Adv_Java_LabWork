package com.cdac;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet2
 */
@WebServlet("/register")
public class RegisterServlet2 extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		int mobileno = Integer.parseInt(request.getParameter("mobileno"));
		String username = request.getParameter("username");
		String password = request.getParameter("password");

		PrintWriter out = response.getWriter();
		out.write("<html><body>");

		RegisterService registerService = new RegisterService(); // create object 
		boolean present = registerService.isCustomerPresent(email);  // call method 
		if(present) {
			out.write("<h1>It seems you are already a registered user!</h1>");
		}
		else {
			registerService.register(name, email, mobileno, username, password);
			out.write("<h1>Registration successful!</h1>");
		}

		out.write("</body></html>");
	}

}
